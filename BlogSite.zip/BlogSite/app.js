import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut as firebaseSignOut, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js';
import { getFirestore, collection, addDoc, query, orderBy, onSnapshot, deleteDoc, doc, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js';

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCjPBe9w0qV3AAuHmLPh2kM4VkWBaMrc60",
    authDomain: "blog-project-99201.firebaseapp.com",
    projectId: "blog-project-99201",
    storageBucket: "blog-project-99201.firebasestorage.app",
    messagingSenderId: "21547273433",
    appId: "1:21547273433:web:21ab0ce773f45ddd5402c8",
    measurementId: "G-6Y54DK95RR"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

let isSignUp = false;
let currentUser = null;
let posts = [];

// Auth state observer
onAuthStateChanged(auth, (user) => {
    if (user) {
        currentUser = user;
        document.getElementById('authSection').style.display = 'none';
        document.getElementById('blogSection').classList.add('active');
        document.getElementById('userEmail').textContent = user.email;
        loadPosts();
    } else {
        currentUser = null;
        document.getElementById('authSection').style.display = 'block';
        document.getElementById('blogSection').classList.remove('active');
    }
});

// Toggle sign in / sign up
document.getElementById('toggleLink').addEventListener('click', () => {
    isSignUp = !isSignUp;
    if (isSignUp) {
        document.getElementById('authTitle').textContent = 'Create Account';
        document.getElementById('authButton').textContent = 'Sign Up';
        document.getElementById('toggleText').textContent = 'Already have an account?';
        document.getElementById('toggleLink').textContent = 'Sign In';
    } else {
        document.getElementById('authTitle').textContent = 'Welcome Back';
        document.getElementById('authButton').textContent = 'Sign In';
        document.getElementById('toggleText').textContent = "Don't have an account?";
        document.getElementById('toggleLink').textContent = 'Sign Up';
    }
    document.getElementById('authMessage').innerHTML = '';
});

// Handle auth form submission
document.getElementById('authForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const messageDiv = document.getElementById('authMessage');

    try {
        if (isSignUp) {
            await createUserWithEmailAndPassword(auth, email, password);
            messageDiv.innerHTML = '<div class="success">Account created successfully!</div>';
        } else {
            await signInWithEmailAndPassword(auth, email, password);
            messageDiv.innerHTML = '<div class="success">Signed in successfully!</div>';
        }
        document.getElementById('authForm').reset();
    } catch (error) {
        messageDiv.innerHTML = `<div class="error">${error.message}</div>`;
    }
});

// Sign out
window.signOut = async () => {
    try {
        await firebaseSignOut(auth);
    } catch (error) {
        console.error('Error signing out:', error);
    }
};

// Handle post submission
document.getElementById('postForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = document.getElementById('postTitle').value;
    const content = document.getElementById('postContent').value;
    const messageDiv = document.getElementById('postMessage');

    try {
        await addDoc(collection(db, 'posts'), {
            title,
            content,
            author: currentUser.email,
            authorId: currentUser.uid,
            createdAt: serverTimestamp()
        });
        messageDiv.innerHTML = '<div class="success">Post published successfully!</div>';
        document.getElementById('postForm').reset();
        setTimeout(() => { messageDiv.innerHTML = ''; }, 3000);
    } catch (error) {
        messageDiv.innerHTML = `<div class="error">${error.message}</div>`;
    }
});

// Load posts
function loadPosts() {
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    onSnapshot(q, (snapshot) => {
        posts = [];
        snapshot.forEach((doc) => { posts.push({ id: doc.id, ...doc.data() }); });
        renderPosts();
    });
}

// Render posts
function renderPosts() {
    const container = document.getElementById('postsContainer');
    if (posts.length === 0) {
        container.innerHTML = '<div class="loading">No posts yet. Be the first to create one!</div>';
        return;
    }

    container.innerHTML = '<div class="posts-grid">' + posts.map(post => {
        const date = post.createdAt ? new Date(post.createdAt.seconds * 1000).toLocaleDateString() : 'Just now';
        const canDelete = currentUser && post.authorId === currentUser.uid;
        return `
            <div class="post-card">
                <div class="post-header">
                    <span class="post-author">By ${post.author}</span>
                    <span class="post-date">${date}</span>
                </div>
                <div class="post-title">${post.title}</div>
                <div class="post-content">${post.content}</div>
                ${canDelete ? `<div class="post-actions"><button class="delete-btn" onclick="deletePost('${post.id}')">Delete</button></div>` : ''}
            </div>
        `;
    }).join('') + '</div>';
}

// Delete post
window.deletePost = async (postId) => {
    if (confirm('Are you sure you want to delete this post?')) {
        try {
            await deleteDoc(doc(db, 'posts', postId));
        } catch (error) {
            alert('Error deleting post: ' + error.message);
        }
    }
};
